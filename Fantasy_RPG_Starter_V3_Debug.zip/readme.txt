Fantasy RPG Starter Version 3 - FRS V3 Debug Edition
---------------------------------------------------
Contents:
- classes.txt, races.txt, skill_trees.txt, areas.txt, towns.txt, quests.txt, dialogue.txt, story.txt, config.txt, readme.txt
Notes:
- Debug mode enabled by default (config.txt). Toggle debug_mode=false to disable.
- Tutorial/trial removed: direct class selection allowed at character creation.
- Attack-button fix: tutorial skip will now auto-equip starter weapon via main_game_script pseudo logic in project.
- To update GitHub: upload these .txt files into your repository root or the data folder used by your game. Commit changes via the web UI or git.
- Version: FRS V3 Debug Edition
